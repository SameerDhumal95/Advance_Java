package study.hw1.controller;

public class product2 {

	private String product;
	private int rating;

	public product2(String product, int i) {
		super();
		this.product = product;
		this.rating = i;
	}
	
	

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}
	
	
}
