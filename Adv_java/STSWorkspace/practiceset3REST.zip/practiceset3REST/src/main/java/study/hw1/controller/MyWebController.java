package study.hw1.controller;

import java.util.List;

import javax.naming.spi.DirStateFactory.Result;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyWebController {

	@Autowired
	private JdbcTemplate template;
	
	@RequestMapping("/index")
	public String index()
	{
		
		return "";
	}
	
	@GetMapping("/add")
	public String add(@RequestParam String product,@RequestParam int rating)
	{
		template.update("insert into product2 values(?,?)",product,rating);
		return "index";
	}
	
	@GetMapping("/show")
	public List<product2> show()
	{
	List<product2> list =  template.query("select * from product2",(rs,rownum)->
	{return new product2(rs.getString(1),rs.getInt(2));});
		
	return list;
	}
}
