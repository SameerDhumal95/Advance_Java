package study.hw1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practiceset3RestApplicationTests {

	@Test
	void contextLoads() {
	}

}
