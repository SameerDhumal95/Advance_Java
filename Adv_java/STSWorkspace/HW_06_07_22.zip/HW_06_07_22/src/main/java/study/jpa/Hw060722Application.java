package study.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hw060722Application {

	public static void main(String[] args) {
		SpringApplication.run(Hw060722Application.class, args);
	}

}
