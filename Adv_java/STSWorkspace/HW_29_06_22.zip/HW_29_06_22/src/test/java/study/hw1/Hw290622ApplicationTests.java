package study.hw1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hw290622ApplicationTests {

	@Test
	void contextLoads() {
	}

}
